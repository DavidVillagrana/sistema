export interface TokenI {
    success: string,
    token: string,
    exp: string,
    message: string
    user:any,
}
